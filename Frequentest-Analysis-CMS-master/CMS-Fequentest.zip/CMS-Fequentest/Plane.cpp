#include "stdafx.h"
#include <algorithm>
#include "Plane.h"

Plane::Plane(std::vector<std::vector<double>>& data)
{
	const int DIMENSIONS = data[0].size();

	//generate starting conditions for the plane
	orthogonal.push_back(1);
	for (unsigned int i = 0; i < DIMENSIONS - 1; ++i)
	{
		orthogonal.push_back(0);
	}
	int bestInd;
	long int min_front = data.size();
	//find the point making the best split in each dimension
	for (int i = 1; i < DIMENSIONS; ++i)
	{
		for (unsigned int j = 0; j < data.size(); ++j)
		{
			points.push_back(data[j]);
			std::vector<std::vector<double>> matrix;
			for (unsigned int k = 0; k < points.size(); ++k)
			{
				auto cur_vect = points[k];
				std::vector<double> cur_dim_vect(cur_vect.begin(), cur_vect.begin() + i);
				matrix.push_back(cur_dim_vect);
			}
			orthogonal = gaussian_Elimination(matrix);
			orthogonal.reserve(DIMENSIONS);
			while (orthogonal.size() < DIMENSIONS)
				orthogonal.push_back(0.0);
			long int front = in_front(orthogonal, data);
			if (front < min_front || data.size() - front < min_front)
				bestInd = j;
			points.erase(points.end());
		}
		points.push_back(data[bestInd]);


		data.erase(data.begin() + bestInd);
	}
	orthogonal = gaussian_Elimination(points);
	if (DIMENSIONS == 1)
	{
		orthogonal = { 1 };
	}
}

double Plane::dot(std::vector<double> vect)
{
	double sum = 0;
	for (unsigned int i = 0; i < orthogonal.size(); ++i)
	{
		sum += orthogonal[i] * vect[i];
	}
	return sum;
}

double Plane::cosine_theta(std::vector<double> vect)
{
	return dot(vect) / (magnitude(vect) * magnitude(orthogonal));
}

